This is a demo project based on blog post https://www.itwonders-web.com/blog/push-notification-using-firebase-demo-tutorial/
